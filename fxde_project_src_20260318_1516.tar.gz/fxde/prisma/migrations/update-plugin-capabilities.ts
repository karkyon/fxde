/**
 * prisma/migrations/update-plugin-capabilities.ts
 * （または prisma/seed-patch-capabilities.ts として独立実行）
 *
 * 既存 seed の capabilitiesJson を runtime 対応値に更新する。
 *
 * 問題:
 *   既存 seed では capabilitiesJson が
 *   ['overlay', 'zone_detection', 'multi_timeframe'] となっている。
 *
 *   しかし Plugin Runtime Resolver は
 *   CHART_RUNTIME_CAPABILITIES = ['chart_overlay', 'chart_signal', 'chart_indicator']
 *   で判定するため、このままでは Supply Demand Zones PRO が実行対象にならない。
 *
 * 解決:
 *   capabilitiesJson に 'chart_overlay' を追加する。
 *   既存の値は保持する（後方互換性）。
 *
 * 実行方法:
 *   pnpm exec tsx prisma/seed-patch-capabilities.ts
 *
 * または prisma/seed.ts の Supply Demand PRO の capabilitiesJson を直接修正:
 *   capabilitiesJson: JSON.stringify([
 *     'chart_overlay',          // ← 追加（runtime 判定キー）
 *     'overlay',
 *     'zone_detection',
 *     'multi_timeframe',
 *   ]),
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function patchCapabilities() {
  console.log('🔌 Plugin capabilities パッチ開始...');

  // Supply Demand Zones PRO に chart_overlay を追加
  const sdPro = await prisma.pluginManifest.findUnique({
    where:  { id: 'plg_supply_demand_pro' },
    select: { id: true, displayName: true, capabilitiesJson: true },
  });

  if (!sdPro) {
    console.error('❌ plg_supply_demand_pro が見つかりません。seed を先に実行してください。');
    process.exit(1);
  }

  const existing: string[] = Array.isArray(sdPro.capabilitiesJson)
    ? (sdPro.capabilitiesJson as string[])
    : [];

  const updated = Array.from(
    new Set(['chart_overlay', ...existing]),  // chart_overlay を先頭に追加、重複排除
  );

  await prisma.pluginManifest.update({
    where: { id: 'plg_supply_demand_pro' },
    data:  { capabilitiesJson: updated },
  });

  console.log(`✅ ${sdPro.displayName} capabilities 更新完了`);
  console.log(`   変更前: ${JSON.stringify(existing)}`);
  console.log(`   変更後: ${JSON.stringify(updated)}`);

  // Trend Bias Analyzer は chart 系 capability なし → runtime 対象外のまま（正しい）
  // Session Overlay Pack は将来 chart_overlay を付与する余地あり

  console.log('\n🎉 capabilities パッチ完了');
  await prisma.$disconnect();
}

patchCapabilities().catch((e) => {
  console.error('❌ パッチ失敗:', e);
  process.exit(1);
});