-- CreateTable
CREATE TABLE "plugin_condition_stats" (
    "id" TEXT NOT NULL,
    "plugin_key" TEXT NOT NULL,
    "condition_key" TEXT NOT NULL,
    "sample_count" INTEGER NOT NULL DEFAULT 0,
    "win_rate" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "avg_return" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "plugin_condition_stats_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "plugin_condition_stats_plugin_key_idx" ON "plugin_condition_stats"("plugin_key");

-- CreateIndex
CREATE UNIQUE INDEX "plugin_condition_stats_plugin_key_condition_key_key" ON "plugin_condition_stats"("plugin_key", "condition_key");
