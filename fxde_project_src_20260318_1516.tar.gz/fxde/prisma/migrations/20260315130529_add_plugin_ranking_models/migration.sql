-- CreateTable
CREATE TABLE "plugin_events" (
    "id" TEXT NOT NULL,
    "plugin_key" TEXT NOT NULL,
    "symbol" VARCHAR(10) NOT NULL,
    "timeframe" VARCHAR(10) NOT NULL,
    "event_type" VARCHAR(20) NOT NULL,
    "direction" VARCHAR(10),
    "price" DOUBLE PRECISION,
    "confidence" DOUBLE PRECISION,
    "metadata" JSONB,
    "emitted_at" TIMESTAMP(3) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "plugin_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "plugin_event_results" (
    "id" TEXT NOT NULL,
    "event_id" TEXT NOT NULL,
    "candle_offset" INTEGER NOT NULL,
    "price_change" DOUBLE PRECISION NOT NULL,
    "return_pct" DOUBLE PRECISION NOT NULL,
    "mfe" DOUBLE PRECISION NOT NULL,
    "mae" DOUBLE PRECISION NOT NULL,
    "evaluated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "plugin_event_results_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "plugin_reliability" (
    "id" TEXT NOT NULL,
    "plugin_key" TEXT NOT NULL,
    "symbol" VARCHAR(10),
    "timeframe" VARCHAR(10),
    "sample_size" INTEGER NOT NULL,
    "win_rate" DOUBLE PRECISION NOT NULL,
    "expectancy" DOUBLE PRECISION NOT NULL,
    "avg_return" DOUBLE PRECISION NOT NULL,
    "avg_mfe" DOUBLE PRECISION NOT NULL,
    "avg_mae" DOUBLE PRECISION NOT NULL,
    "reliability_score" DOUBLE PRECISION NOT NULL,
    "stability_score" DOUBLE PRECISION NOT NULL,
    "confidence_score" DOUBLE PRECISION NOT NULL,
    "state" VARCHAR(20) NOT NULL,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "plugin_reliability_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "plugin_adaptive_decisions" (
    "id" TEXT NOT NULL,
    "plugin_key" TEXT NOT NULL,
    "symbol" VARCHAR(10),
    "timeframe" VARCHAR(10),
    "context_hash" TEXT,
    "global_score" DOUBLE PRECISION NOT NULL,
    "contextual_score" DOUBLE PRECISION NOT NULL,
    "final_rank_score" DOUBLE PRECISION NOT NULL,
    "rank_position" INTEGER NOT NULL,
    "action" VARCHAR(20) NOT NULL,
    "reason_codes" JSONB,
    "decided_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "plugin_adaptive_decisions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "plugin_events_plugin_key_symbol_timeframe_emitted_at_idx" ON "plugin_events"("plugin_key", "symbol", "timeframe", "emitted_at" DESC);

-- CreateIndex
CREATE INDEX "plugin_events_emitted_at_idx" ON "plugin_events"("emitted_at");

-- CreateIndex
CREATE INDEX "plugin_event_results_event_id_idx" ON "plugin_event_results"("event_id");

-- CreateIndex
CREATE INDEX "plugin_reliability_plugin_key_symbol_timeframe_idx" ON "plugin_reliability"("plugin_key", "symbol", "timeframe");

-- CreateIndex
CREATE INDEX "plugin_adaptive_decisions_plugin_key_decided_at_idx" ON "plugin_adaptive_decisions"("plugin_key", "decided_at" DESC);

-- AddForeignKey
ALTER TABLE "plugin_event_results" ADD CONSTRAINT "plugin_event_results_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "plugin_events"("id") ON DELETE CASCADE ON UPDATE CASCADE;
