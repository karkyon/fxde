-- CreateEnum
CREATE TYPE "PluginType" AS ENUM ('pattern', 'indicator', 'strategy', 'risk', 'overlay', 'signal', 'ai', 'connector');

-- CreateEnum
CREATE TYPE "PluginStatus" AS ENUM ('enabled', 'disabled', 'error', 'incompatible', 'missing_dependency', 'update_available');

-- CreateEnum
CREATE TYPE "PluginInstallScope" AS ENUM ('system', 'user');

-- CreateTable
CREATE TABLE "plugin_manifests" (
    "id" TEXT NOT NULL,
    "slug" VARCHAR(191) NOT NULL,
    "display_name" VARCHAR(191) NOT NULL,
    "version" VARCHAR(64) NOT NULL,
    "description_short" VARCHAR(300) NOT NULL,
    "description_long" TEXT NOT NULL,
    "plugin_type" "PluginType" NOT NULL,
    "author_name" VARCHAR(191) NOT NULL,
    "source_label" VARCHAR(191) NOT NULL,
    "homepage_url" VARCHAR(500),
    "docs_url" VARCHAR(500),
    "cover_image_url" VARCHAR(500),
    "icon_url" VARCHAR(500),
    "readme_markdown" TEXT,
    "source_preview" TEXT,
    "entry_file" VARCHAR(500) NOT NULL,
    "checksum" VARCHAR(191) NOT NULL,
    "fxde_api_version" VARCHAR(64) NOT NULL,
    "fxde_web_version" VARCHAR(64) NOT NULL,
    "capabilities_json" JSONB NOT NULL,
    "permissions_json" JSONB NOT NULL,
    "dependencies_json" JSONB NOT NULL,
    "optional_deps_json" JSONB NOT NULL,
    "tags_json" JSONB NOT NULL,
    "is_core" BOOLEAN NOT NULL DEFAULT false,
    "is_signed" BOOLEAN NOT NULL DEFAULT false,
    "install_scope" "PluginInstallScope" NOT NULL DEFAULT 'system',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "plugin_manifests_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "installed_plugins" (
    "id" TEXT NOT NULL,
    "plugin_manifest_id" TEXT NOT NULL,
    "installed_by_user_id" TEXT,
    "is_enabled" BOOLEAN NOT NULL DEFAULT false,
    "status" "PluginStatus" NOT NULL DEFAULT 'disabled',
    "error_message" TEXT,
    "config_locked" BOOLEAN NOT NULL DEFAULT true,
    "installed_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "enable_updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "last_health_check_at" TIMESTAMP(3),
    "last_executed_at" TIMESTAMP(3),

    CONSTRAINT "installed_plugins_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "plugin_audit_logs" (
    "id" TEXT NOT NULL,
    "plugin_manifest_id" TEXT NOT NULL,
    "actor_user_id" TEXT,
    "action" VARCHAR(64) NOT NULL,
    "before_state_json" JSONB NOT NULL,
    "after_state_json" JSONB NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "plugin_audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "plugin_manifests_slug_key" ON "plugin_manifests"("slug");

-- CreateIndex
CREATE INDEX "plugin_manifests_plugin_type_idx" ON "plugin_manifests"("plugin_type");

-- CreateIndex
CREATE INDEX "plugin_manifests_is_core_idx" ON "plugin_manifests"("is_core");

-- CreateIndex
CREATE UNIQUE INDEX "installed_plugins_plugin_manifest_id_key" ON "installed_plugins"("plugin_manifest_id");

-- CreateIndex
CREATE INDEX "installed_plugins_status_idx" ON "installed_plugins"("status");

-- CreateIndex
CREATE INDEX "installed_plugins_is_enabled_idx" ON "installed_plugins"("is_enabled");

-- CreateIndex
CREATE INDEX "plugin_audit_logs_plugin_manifest_id_created_at_idx" ON "plugin_audit_logs"("plugin_manifest_id", "created_at");

-- AddForeignKey
ALTER TABLE "installed_plugins" ADD CONSTRAINT "installed_plugins_plugin_manifest_id_fkey" FOREIGN KEY ("plugin_manifest_id") REFERENCES "plugin_manifests"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "plugin_audit_logs" ADD CONSTRAINT "plugin_audit_logs_plugin_manifest_id_fkey" FOREIGN KEY ("plugin_manifest_id") REFERENCES "plugin_manifests"("id") ON DELETE CASCADE ON UPDATE CASCADE;
