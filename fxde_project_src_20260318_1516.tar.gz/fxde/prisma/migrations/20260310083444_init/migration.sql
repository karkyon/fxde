-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('FREE', 'BASIC', 'PRO', 'PRO_PLUS', 'ADMIN');

-- CreateEnum
CREATE TYPE "UserStatus" AS ENUM ('ACTIVE', 'SUSPENDED');

-- CreateEnum
CREATE TYPE "Preset" AS ENUM ('conservative', 'standard', 'aggressive');

-- CreateEnum
CREATE TYPE "TradeSide" AS ENUM ('BUY', 'SELL');

-- CreateEnum
CREATE TYPE "TradeStatus" AS ENUM ('OPEN', 'CLOSED', 'CANCELED');

-- CreateEnum
CREATE TYPE "EntryState" AS ENUM ('ENTRY_OK', 'SCORE_LOW', 'RISK_NG', 'LOCKED', 'COOLDOWN');

-- CreateEnum
CREATE TYPE "Timeframe" AS ENUM ('M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'H8', 'D1', 'W1', 'MN');

-- CreateEnum
CREATE TYPE "JobStatus" AS ENUM ('QUEUED', 'RUNNING', 'SUCCEEDED', 'FAILED');

-- CreateEnum
CREATE TYPE "SignalType" AS ENUM ('ENTRY_OK', 'LOCKED_EVENT', 'LOCKED_FORCE', 'COOLDOWN', 'BREAKOUT', 'PATTERN_DETECTED');

-- CreateEnum
CREATE TYPE "ImportanceLevel" AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL');

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password_hash" TEXT NOT NULL,
    "role" "UserRole" NOT NULL DEFAULT 'FREE',
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "last_login_at" TIMESTAMP(3),

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sessions" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "refresh_token_hash" TEXT NOT NULL,
    "user_agent" TEXT,
    "ip_address" TEXT,
    "expires_at" TIMESTAMP(3) NOT NULL,
    "revoked_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_settings" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "preset" "Preset" NOT NULL DEFAULT 'standard',
    "score_threshold" INTEGER NOT NULL DEFAULT 75,
    "risk_profile" JSONB NOT NULL DEFAULT '{}',
    "ui_prefs" JSONB NOT NULL DEFAULT '{}',
    "feature_switches" JSONB NOT NULL DEFAULT '{}',
    "force_lock" BOOLEAN NOT NULL DEFAULT false,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "user_settings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "symbol_settings" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "symbol" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "default_timeframe" "Timeframe" NOT NULL DEFAULT 'H4',
    "custom_threshold" INTEGER,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "symbol_settings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "trades" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "symbol" TEXT NOT NULL,
    "side" "TradeSide" NOT NULL,
    "entry_time" TIMESTAMP(3) NOT NULL,
    "entry_price" DECIMAL(10,5) NOT NULL,
    "exit_time" TIMESTAMP(3),
    "exit_price" DECIMAL(10,5),
    "size" DECIMAL(10,4) NOT NULL,
    "sl" DECIMAL(10,5),
    "tp" DECIMAL(10,5),
    "pnl" DECIMAL(12,2),
    "pips" DECIMAL(8,1),
    "status" "TradeStatus" NOT NULL DEFAULT 'OPEN',
    "tags" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "note" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "trades_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "trade_reviews" (
    "id" TEXT NOT NULL,
    "trade_id" TEXT NOT NULL,
    "score_at_entry" INTEGER NOT NULL,
    "rule_checks" JSONB NOT NULL,
    "psychology" JSONB NOT NULL DEFAULT '{}',
    "disciplined" BOOLEAN NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "trade_reviews_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "snapshots" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "symbol" TEXT NOT NULL,
    "timeframe" "Timeframe" NOT NULL,
    "captured_at" TIMESTAMP(3) NOT NULL,
    "indicators" JSONB NOT NULL,
    "patterns" JSONB NOT NULL DEFAULT '[]',
    "mtf_alignment" JSONB NOT NULL DEFAULT '{}',
    "score_total" INTEGER NOT NULL,
    "score_breakdown" JSONB NOT NULL,
    "entry_state" "EntryState" NOT NULL,
    "entry_context" JSONB NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "snapshots_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "signals" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "symbol" TEXT NOT NULL,
    "timeframe" "Timeframe" NOT NULL,
    "snapshot_id" TEXT NOT NULL,
    "triggered_at" TIMESTAMP(3) NOT NULL,
    "type" "SignalType" NOT NULL,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "acknowledged_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "signals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "prediction_jobs" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "symbol" TEXT NOT NULL,
    "timeframe" "Timeframe" NOT NULL,
    "request_data" JSONB NOT NULL,
    "status" "JobStatus" NOT NULL DEFAULT 'QUEUED',
    "started_at" TIMESTAMP(3),
    "finished_at" TIMESTAMP(3),
    "error_message" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "prediction_jobs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "prediction_results" (
    "id" TEXT NOT NULL,
    "job_id" TEXT NOT NULL,
    "result_data" JSONB NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "prediction_results_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "interest_rates" (
    "id" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "bank" TEXT NOT NULL,
    "currency" TEXT NOT NULL,
    "rate" DECIMAL(5,3) NOT NULL,
    "effective_at" TIMESTAMP(3) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "interest_rates_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "economic_events" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "currency" TEXT NOT NULL,
    "scheduled_at" TIMESTAMP(3) NOT NULL,
    "importance" "ImportanceLevel" NOT NULL,
    "actual" DECIMAL(10,4),
    "forecast" DECIMAL(10,4),
    "previous" DECIMAL(10,4),
    "deviation" DECIMAL(10,4),
    "source" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "economic_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" TEXT NOT NULL,
    "user_id" TEXT,
    "action" TEXT NOT NULL,
    "target_type" TEXT,
    "target_id" TEXT,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "ip_address" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "market_candles" (
    "id" TEXT NOT NULL,
    "symbol" VARCHAR(10) NOT NULL,
    "timeframe" "Timeframe" NOT NULL,
    "time" TIMESTAMPTZ(6) NOT NULL,
    "open" DECIMAL(18,6) NOT NULL,
    "high" DECIMAL(18,6) NOT NULL,
    "low" DECIMAL(18,6) NOT NULL,
    "close" DECIMAL(18,6) NOT NULL,
    "volume" BIGINT NOT NULL,
    "source" VARCHAR(50) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "market_candles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "indicator_cache" (
    "id" TEXT NOT NULL,
    "symbol" VARCHAR(10) NOT NULL,
    "timeframe" "Timeframe" NOT NULL,
    "calculated_at" TIMESTAMPTZ(6) NOT NULL,
    "indicators" JSONB NOT NULL,
    "source" VARCHAR(50) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "indicator_cache_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "pattern_detections" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "symbol" VARCHAR(10) NOT NULL,
    "timeframe" "Timeframe" NOT NULL,
    "pattern_name" VARCHAR(100) NOT NULL,
    "pattern_category" VARCHAR(20) NOT NULL,
    "direction" VARCHAR(10) NOT NULL,
    "confidence" DECIMAL(5,4) NOT NULL,
    "detected_at" TIMESTAMPTZ(6) NOT NULL,
    "bar_index" INTEGER NOT NULL,
    "price" DECIMAL(18,6) NOT NULL,
    "label" VARCHAR(50) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "pattern_detections_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "chart_snapshots" (
    "id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "symbol" VARCHAR(10) NOT NULL,
    "timeframe" "Timeframe" NOT NULL,
    "captured_at" TIMESTAMPTZ(6) NOT NULL,
    "chart_config" JSONB NOT NULL,
    "overlay_state" JSONB NOT NULL,
    "notes" TEXT,
    "trade_id" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "chart_snapshots_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE INDEX "sessions_user_id_idx" ON "sessions"("user_id");

-- CreateIndex
CREATE INDEX "sessions_expires_at_idx" ON "sessions"("expires_at");

-- CreateIndex
CREATE UNIQUE INDEX "user_settings_user_id_key" ON "user_settings"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "symbol_settings_user_id_symbol_key" ON "symbol_settings"("user_id", "symbol");

-- CreateIndex
CREATE INDEX "trades_user_id_status_idx" ON "trades"("user_id", "status");

-- CreateIndex
CREATE INDEX "trades_user_id_symbol_idx" ON "trades"("user_id", "symbol");

-- CreateIndex
CREATE INDEX "trades_user_id_entry_time_idx" ON "trades"("user_id", "entry_time");

-- CreateIndex
CREATE UNIQUE INDEX "trade_reviews_trade_id_key" ON "trade_reviews"("trade_id");

-- CreateIndex
CREATE INDEX "snapshots_user_id_symbol_captured_at_idx" ON "snapshots"("user_id", "symbol", "captured_at");

-- CreateIndex
CREATE INDEX "snapshots_user_id_entry_state_idx" ON "snapshots"("user_id", "entry_state");

-- CreateIndex
CREATE INDEX "signals_user_id_acknowledged_at_idx" ON "signals"("user_id", "acknowledged_at");

-- CreateIndex
CREATE INDEX "signals_user_id_triggered_at_idx" ON "signals"("user_id", "triggered_at");

-- CreateIndex
CREATE INDEX "prediction_jobs_user_id_status_idx" ON "prediction_jobs"("user_id", "status");

-- CreateIndex
CREATE INDEX "prediction_jobs_user_id_created_at_idx" ON "prediction_jobs"("user_id", "created_at");

-- CreateIndex
CREATE UNIQUE INDEX "prediction_results_job_id_key" ON "prediction_results"("job_id");

-- CreateIndex
CREATE INDEX "interest_rates_currency_effective_at_idx" ON "interest_rates"("currency", "effective_at");

-- CreateIndex
CREATE INDEX "economic_events_scheduled_at_importance_idx" ON "economic_events"("scheduled_at", "importance");

-- CreateIndex
CREATE INDEX "economic_events_currency_scheduled_at_idx" ON "economic_events"("currency", "scheduled_at");

-- CreateIndex
CREATE INDEX "audit_logs_user_id_created_at_idx" ON "audit_logs"("user_id", "created_at");

-- CreateIndex
CREATE INDEX "audit_logs_action_created_at_idx" ON "audit_logs"("action", "created_at");

-- CreateIndex
CREATE INDEX "market_candles_symbol_timeframe_time_idx" ON "market_candles"("symbol", "timeframe", "time" DESC);

-- CreateIndex
CREATE UNIQUE INDEX "market_candles_symbol_timeframe_time_key" ON "market_candles"("symbol", "timeframe", "time");

-- CreateIndex
CREATE INDEX "indicator_cache_symbol_timeframe_calculated_at_idx" ON "indicator_cache"("symbol", "timeframe", "calculated_at" DESC);

-- CreateIndex
CREATE INDEX "indicator_cache_calculated_at_idx" ON "indicator_cache"("calculated_at");

-- CreateIndex
CREATE INDEX "pattern_detections_user_id_symbol_timeframe_detected_at_idx" ON "pattern_detections"("user_id", "symbol", "timeframe", "detected_at" DESC);

-- CreateIndex
CREATE INDEX "pattern_detections_user_id_detected_at_idx" ON "pattern_detections"("user_id", "detected_at" DESC);

-- CreateIndex
CREATE INDEX "chart_snapshots_user_id_symbol_captured_at_idx" ON "chart_snapshots"("user_id", "symbol", "captured_at" DESC);

-- CreateIndex
CREATE INDEX "chart_snapshots_user_id_captured_at_idx" ON "chart_snapshots"("user_id", "captured_at" DESC);

-- AddForeignKey
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_settings" ADD CONSTRAINT "user_settings_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "symbol_settings" ADD CONSTRAINT "symbol_settings_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "trades" ADD CONSTRAINT "trades_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "trade_reviews" ADD CONSTRAINT "trade_reviews_trade_id_fkey" FOREIGN KEY ("trade_id") REFERENCES "trades"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "snapshots" ADD CONSTRAINT "snapshots_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "signals" ADD CONSTRAINT "signals_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "signals" ADD CONSTRAINT "signals_snapshot_id_fkey" FOREIGN KEY ("snapshot_id") REFERENCES "snapshots"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "prediction_jobs" ADD CONSTRAINT "prediction_jobs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "prediction_results" ADD CONSTRAINT "prediction_results_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "prediction_jobs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pattern_detections" ADD CONSTRAINT "pattern_detections_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "chart_snapshots" ADD CONSTRAINT "chart_snapshots_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
