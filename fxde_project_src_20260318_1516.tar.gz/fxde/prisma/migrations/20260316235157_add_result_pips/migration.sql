-- AlterTable
ALTER TABLE "plugin_event_results" ADD COLUMN     "result_pips" DOUBLE PRECISION;
